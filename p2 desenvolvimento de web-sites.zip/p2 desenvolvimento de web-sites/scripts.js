// Rolagem suave para seções
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    section.scrollIntoView({ behavior: 'smooth' });
  }
  
  // Formulário de envio (simulação)
  document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Mensagem enviada com sucesso!');
  });
  function setBackground(type) {
    const body = document.body;
  
    // Remove todas as classes de fundo existentes
    body.classList.remove('gradient', 'image', 'solid-color', 'image-overlay');
  
    // Adiciona a classe correspondente ao tipo de fundo
    if (type === 'gradient') {
      body.classList.add('gradient');
    } else if (type === 'image') {
      body.classList.add('image');
    } else if (type === 'solid-color') {
      body.classList.add('solid-color');
    } else if (type === 'image-overlay') {
      body.classList.add('image-overlay');
    } else if (type === 'reset') {
      body.style.background = "none"; // Remove fundo personalizado
      body.style.color = "#000"; // Reseta a cor do texto para o padrão
    }
  }
  